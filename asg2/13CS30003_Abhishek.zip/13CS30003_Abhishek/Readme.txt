Abhishek Niranjan
13CS3000

1. I have merged the functions of main.py and train.py into one file only - Assignment2_13CS30003.py
2. To run the code, please use:
	python Assignment2_13CS30003.py
3. The numpy arrays for the weight parameters of the network are pickled in the *.npy files.


